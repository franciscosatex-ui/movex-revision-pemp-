MOVEX Revisión PEMP — proyecto Android

Incluye los 81 puntos extraídos del Excel Hoja de Revisión (1).xlsx, el logotipo MOVEX extraído del propio Excel, controles F/DL/DG/NA, datos de la revisión, observaciones, resultado, exportación TXT y preparación de correo mediante la aplicación de correo del dispositivo.

ESTADO: es el código fuente de un proyecto Android, NO un APK compilado. Este entorno no tiene Android SDK ni Gradle instalados, por lo que no puedo compilar ni verificar un APK aquí. Para generar el APK: abrir la carpeta MOVEXRevisionPEMP en Android Studio, permitir que Gradle sincronice, y seleccionar Build > Build APK(s). El APK de depuración se generará en app/build/outputs/apk/debug/app-debug.apk.

Nota: el envío por correo se prepara en la app de correo del móvil y el usuario debe confirmar el envío; la aplicación no puede detectar si el mensaje se ha enviado realmente. Los datos no se borran al abrir el correo; solo se borran con el botón Nueva revisión.
