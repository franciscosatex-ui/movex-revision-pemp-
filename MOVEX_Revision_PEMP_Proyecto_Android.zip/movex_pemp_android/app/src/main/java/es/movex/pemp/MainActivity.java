package es.movex.pemp;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebChromeClient;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
 @Override public void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); WebView w=new WebView(this); w.getSettings().setJavaScriptEnabled(true); w.getSettings().setDomStorageEnabled(true); w.setWebChromeClient(new WebChromeClient()); w.setWebViewClient(new WebViewClient(){ @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){ Uri u=request.getUrl(); if("mailto".equals(u.getScheme())) { try { startActivity(new Intent(Intent.ACTION_SENDTO,u)); } catch(Exception e){} return true; } return false; }}); setContentView(w); w.loadUrl("file:///android_asset/index.html"); }
 @Override public void onBackPressed(){ super.onBackPressed(); }
}
